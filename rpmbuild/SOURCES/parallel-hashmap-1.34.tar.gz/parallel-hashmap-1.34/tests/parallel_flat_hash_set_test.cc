#define THIS_HASH_SET  parallel_flat_hash_set
#define THIS_TEST_NAME ParallelFlatHashSet

#include "parallel_hash_set_test.cc"

